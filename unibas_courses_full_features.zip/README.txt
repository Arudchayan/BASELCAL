Expanded JSON extraction from University of Basel course-directory pages/search results. See metadata in JSON for schema, scope, and limitations.
